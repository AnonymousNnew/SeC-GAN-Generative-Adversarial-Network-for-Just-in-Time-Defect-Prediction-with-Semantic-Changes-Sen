from setuptools import setup, find_packages

setup(
    name='javadiff',
    version='0.0.1',
    packages=find_packages(),
    url='',
    license='',
    author='Amir Elmishali',
    author_email='amir9979@gmail.com',
    description=''
)
